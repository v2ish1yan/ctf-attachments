<form method="post" action="index.php">
    <label for="filepath">file path:</label>
    <input type="text" name="filepath" id="filepath" required>
    <br><br>
    <input type="submit" value="submit">
</form>
<?php
echo "Please select an image to check";